#!/usr/bin/env bash
# run.sh

make;
./app $1 $2;